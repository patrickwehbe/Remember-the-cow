<div class="headfoot">
    <p>
        "Remember The Cow is nice, but it's a total copy of another site." - PCWorld <br/>
        All pages and content &copy; Copyright CowPie Inc.
    </p>

    <div id="w3c">
        <a href="https://validator.w3.org/check/referer">
            <img src="https://webster.cs.washington.edu/w3c-html.png" alt="Valid HTML"/></a>
        <a href="https://jigsaw.w3.org/css-validator/check/referer">
            <img src="https://webster.cs.washington.edu/w3c-css.png" alt="Valid CSS"/></a>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/prototype/1.7.0.0/prototype.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/scriptaculous/1.9.0/scriptaculous.js"></script>
<script src="todolist.js"></script>
</body>
</html>